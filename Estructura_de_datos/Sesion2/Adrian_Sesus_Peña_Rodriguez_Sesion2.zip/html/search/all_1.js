var searchData=
[
  ['database',['database',['../classenfermedad.html#a3684b7ec850d4c9357dd21bdd5e02803',1,'enfermedad']]],
  ['documentacion_2edox',['documentacion.dox',['../documentacion_8dox.html',1,'']]],
  ['documentación_20práctica',['Documentación Práctica',['../index.html',1,'']]]
];
