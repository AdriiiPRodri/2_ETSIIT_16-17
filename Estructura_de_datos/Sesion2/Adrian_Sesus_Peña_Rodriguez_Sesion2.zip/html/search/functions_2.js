var searchData=
[
  ['getcaf',['getCaf',['../classmutacion.html#a2d60aed548b4b151bc2c198e989faa20',1,'mutacion']]],
  ['getchr',['getChr',['../classmutacion.html#aefb0a9a6a8278f0d192ebc044198399c',1,'mutacion']]],
  ['getclnsig',['getClnsig',['../classmutacion.html#ad555ad20ff5cdb729fe7187e4547bc9f',1,'mutacion']]],
  ['getcommon',['getCommon',['../classmutacion.html#abc353016535a561fbd8e902c83861228',1,'mutacion']]],
  ['getdatabase',['getDatabase',['../classenfermedad.html#a79d304a2e39ea391917744fd4d8f168d',1,'enfermedad']]],
  ['getenfermedades',['getEnfermedades',['../classmutacion.html#aec4992d4eab534b66fb572ff985d0b02',1,'mutacion']]],
  ['getgenes',['getGenes',['../classmutacion.html#a547be4b8d179d85cf46e7c311ce354c1',1,'mutacion']]],
  ['getid',['getID',['../classenfermedad.html#aaf9b9135b1d4efda7dc61856fce1b7b2',1,'enfermedad::getID()'],['../classmutacion.html#a6e3fa261f38b413aff9172fe065da8b8',1,'mutacion::getID()']]],
  ['getname',['getName',['../classenfermedad.html#ab22f6f0140a5fe5a331d72920d95f55b',1,'enfermedad']]],
  ['getpos',['getPos',['../classmutacion.html#ad08cb3c30da4195adc3c22d0b4c8edd7',1,'mutacion']]],
  ['getref_5falt',['getRef_alt',['../classmutacion.html#ad2e2452d29875aeed6dff7a98327135a',1,'mutacion']]]
];
