var searchData=
[
  ['operator_21_3d',['operator!=',['../classenfermedad.html#a85bf5cbb035fd4712ff9a72188060e5c',1,'enfermedad']]],
  ['operator_3c',['operator&lt;',['../classenfermedad.html#a2b3361849fa17dc88be561cd4233d584',1,'enfermedad::operator&lt;()'],['../classmutacion.html#a0ccb4444b7afd120dc4557fd05f9ca27',1,'mutacion::operator&lt;()']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../enfermedad_8h.html#a6cabaa51c1fab8960486e2c2e51071f0',1,'operator&lt;&lt;(ostream &amp;os, const enfermedad &amp;e):&#160;enfermedad.hxx'],['../mutacion_8h.html#aca11da8905b0a8e522d7acbc2c0f6521',1,'operator&lt;&lt;(ostream &amp;, const mutacion &amp;):&#160;mutacion.hxx'],['../mutacion_8hxx.html#a174b968fc96955d6be461eaed92a36fd',1,'operator&lt;&lt;(ostream &amp;os, const mutacion &amp;mutacion):&#160;mutacion.hxx'],['../enfermedad_8hxx.html#a6cabaa51c1fab8960486e2c2e51071f0',1,'operator&lt;&lt;(ostream &amp;os, const enfermedad &amp;e):&#160;enfermedad.hxx']]],
  ['operator_3d',['operator=',['../classenfermedad.html#a795be16b7e3e6a858211ff20a62c9d85',1,'enfermedad::operator=()'],['../classmutacion.html#a183a12f2fae6160c9f381bd48d719a23',1,'mutacion::operator=()']]],
  ['operator_3d_3d',['operator==',['../classenfermedad.html#ac2786ad7be914729516dd15611532fbb',1,'enfermedad::operator==()'],['../classmutacion.html#a2e36c20aeff8c7cc88abe84efe0b11be',1,'mutacion::operator==()']]]
];
